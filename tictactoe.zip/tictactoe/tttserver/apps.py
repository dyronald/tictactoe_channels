from django.apps import AppConfig


class TttserverConfig(AppConfig):
    name = 'tttserver'
